# Team Stats Dashboard (Google Sheets -> Website)

This is a lightweight, no-backend website that reads a CSV and gives you:
- filtering by **Player** and **Game**
- sorting any stat column
- optional **Statistic focus** dropdown (shows just Player + Game + one chosen stat)
- export the filtered table to CSV

## Quick start (local)
1. Put your CSV at `data/player_game_stats_long.csv` (already included as a starter export)
2. Open `index.html` with a local web server (recommended), e.g.
   - VS Code: install “Live Server” and click “Go Live”
   - or run: `python -m http.server 8000` and open http://localhost:8000

> Note: Some browsers block loading local files via `file://`. Using a local server fixes this.

## Keeping it updated from Google Sheets (recommended)
1. In Google Sheets: **File → Share → Publish to web**
2. Choose the tab that contains your long-form data (one row per player per game) and pick **CSV**
3. Copy the published CSV URL
4. In `app.js`, set:
   `const CSV_URL = "YOUR_PUBLISHED_CSV_URL";`

Now every time you update your Google Sheet, the website updates automatically.

## Making a long-form tab inside Google Sheets
The website expects columns like: Player, Game, FGM, FGA, ... (whatever you track).

Easiest approach:
- Create a new tab called **LongData**
- Use an Apps Script to stack your player tabs into one table

A sample Apps Script is included in `tools/consolidate.gs`.
